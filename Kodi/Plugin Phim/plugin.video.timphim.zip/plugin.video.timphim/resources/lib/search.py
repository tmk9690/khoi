"""Tìm kiếm gộp KKPhim + NguonC + VSMOV.

Mỗi nguồn được gọi song song, kết quả được chuẩn hoá rồi gộp các phim trùng
nhau (cùng tên gốc, không mâu thuẫn năm) thành một mục duy nhất.
Phát phim vẫn dùng nguyên logic của từng add-on gốc (đã được đóng gói trong
resources/lib/kk, nc, vs).
"""
import json
import os
import re
import unicodedata
from concurrent.futures import ThreadPoolExecutor
from html import unescape

from codequick import Route, Listitem, Script
from xbmc import Keyboard, executebuiltin
from xbmcvfs import translatePath

from resources.lib.kk import kkphim, utils as kk_utils
from resources.lib.nc import nguonc, utils as nc_utils
from resources.lib.vs import vsmov, utils as vs_utils

ADDON_ID = 'plugin.video.timphim'
RESULT_LIMIT = 24      # số kết quả tối đa lấy từ mỗi nguồn
HTTP_TIMEOUT = 15      # giây, để một nguồn chậm không làm treo cả tìm kiếm
HISTORY_FILE = 'search_history.json'
MAX_HISTORY = 20

# key: (tên đầy đủ, tên ngắn, màu, hàm chi tiết của add-on gốc)
SOURCES = {
    'kk': ('KKPhim', 'KK', 'FF4FC3F7', kkphim.chi_tiet),
    'nc': ('NguonC', 'NC', 'FFFFB74D', nguonc.chi_tiet),
    'vs': ('VSMOV', 'VS', 'FF81C784', vsmov.chi_tiet),
}
ORDER = ('kk', 'nc', 'vs')


# ============================================================
# TIỆN ÍCH
# ============================================================

def _norm(text):
    """Bỏ dấu, chữ thường, chỉ giữ chữ-số: dùng làm khoá so khớp tên."""
    text = unicodedata.normalize('NFD', str(text or ''))
    text = ''.join(c for c in text if unicodedata.category(c) != 'Mn')
    text = text.replace('đ', 'd').replace('Đ', 'D')
    return re.sub(r'[^a-z0-9]+', '', text.lower())


def _clean_html(text):
    return re.sub(r'<[^>]+>', '', unescape(text or '')).strip()


def _year(value):
    try:
        y = int(str(value).strip()[:4])
        return y if 1850 < y < 2100 else None
    except (TypeError, ValueError):
        return None


def _items_of(data):
    """Lấy danh sách phim từ các dạng phản hồi khác nhau của 3 API."""
    if not isinstance(data, dict):
        return []
    root = data.get('data') if isinstance(data.get('data'), dict) else data
    items = root.get('items') or data.get('items') or []
    return [i for i in items if isinstance(i, dict)] if isinstance(items, list) else []


def _entry(src, m, name, origin, year, poster, thumb, plot, tags=''):
    return {
        'src': src,
        'slug': m.get('slug'),
        'name': (name or '').strip(),
        'origin': (origin or '').strip(),
        'year': _year(year),
        'poster': poster,
        'thumb': thumb,
        'plot': plot or '',
        'tags': tags,
    }


# ============================================================
# LẤY DỮ LIỆU TỪNG NGUỒN  (trả về None nếu lỗi mạng/API)
# ============================================================

def _fetch_kk(query):
    data = kk_utils.get_json(
        f'{kk_utils.BASE_API}/v1/api/tim-kiem',
        {'keyword': query, 'limit': RESULT_LIMIT}, timeout=HTTP_TIMEOUT,
    )
    if data is None:
        return None
    root = data.get('data') if isinstance(data.get('data'), dict) else {}
    cdn = (root.get('APP_DOMAIN_CDN_IMAGE') or 'https://phimimg.com').rstrip('/')

    def img(path):
        if isinstance(path, str) and path.startswith('http'):
            return path
        if isinstance(path, str) and path.strip():
            return f'{cdn}/{path.strip().lstrip("/")}'
        return None

    out = []
    for m in _items_of(data):
        if not m.get('slug'):
            continue
        poster = kk_utils.fix_image(img(m.get('poster_url')) or img(m.get('thumb_url')))
        thumb = kk_utils.fix_image(img(m.get('thumb_url')) or img(m.get('poster_url')))
        tags = ' | '.join(
            t for t in ((m.get('quality') or '').strip(),
                        (m.get('episode_current') or '').strip()) if t
        )
        out.append(_entry('kk', m, m.get('name'), m.get('origin_name'),
                          m.get('year'), poster, thumb, '', tags))
    return out


def _fetch_nc(query):
    data = nc_utils.get_json(
        f'{nc_utils.BASE_API}/films/search',
        {'keyword': query, 'page': 1}, timeout=HTTP_TIMEOUT,
    )
    if data is None:
        return None
    out = []
    for m in _items_of(data):
        if not m.get('slug'):
            continue
        poster = nc_utils.fix_image(m.get('poster_url') or m.get('thumb_url'))
        thumb = nc_utils.fix_image(m.get('thumb_url') or m.get('poster_url'))
        tags = ' | '.join(
            t for t in ((m.get('quality') or '').strip(),
                        (m.get('current_episode') or '').strip()) if t
        )
        out.append(_entry(
            'nc', m, m.get('name') or m.get('original_name'),
            m.get('original_name') or m.get('origin_name'),
            m.get('year'), poster, thumb, _clean_html(m.get('description')), tags,
        ))
    return out


def _fetch_vs(query):
    data = vs_utils.get_json(
        f'{vs_utils.BASE_API}/tim-kiem',
        {'keyword': query, 'limit': RESULT_LIMIT, 'page': 1}, timeout=HTTP_TIMEOUT,
    )
    if data is None:
        return None
    out = []
    for m in _items_of(data):
        if not m.get('slug'):
            continue
        poster = vs_utils.fix_image(m.get('poster_url') or m.get('thumb_url'))
        thumb = vs_utils.fix_image(m.get('thumb_url') or m.get('poster_url'))
        out.append(_entry('vs', m, m.get('name'), m.get('origin_name'),
                          m.get('year'), poster, thumb, ''))
    return out


FETCHERS = {'kk': _fetch_kk, 'nc': _fetch_nc, 'vs': _fetch_vs}


def _safe(src, query):
    try:
        return FETCHERS[src](query)
    except Exception as e:  # một nguồn hỏng không được làm hỏng cả tìm kiếm
        Script.log(f'[TimPhim] Lỗi nguồn {src}: {e}')
        return None


def search_all(query):
    """Trả về (results, failed). results: {src: list|None}; failed: [src]."""
    with ThreadPoolExecutor(max_workers=len(ORDER)) as ex:
        futures = {s: ex.submit(_safe, s, query) for s in ORDER}
        results = {s: f.result() for s, f in futures.items()}
    failed = [s for s, r in results.items() if r is None]
    return results, failed


# ============================================================
# GỘP KẾT QUẢ
# ============================================================

def merge_results(results):
    """Gộp phim trùng giữa các nguồn.

    Hai mục được gộp khi: khác nguồn, chung ít nhất một khoá tên
    (tên Việt hoặc tên gốc, đã bỏ dấu) và không mâu thuẫn về năm.
    """
    groups = []
    rank = 0
    for src in ORDER:
        for e in results.get(src) or []:
            keys = {k for k in (_norm(e['name']), _norm(e['origin'])) if k}
            if not keys:
                continue
            target = None
            for g in groups:
                if src in g['entries']:
                    continue
                if not (keys & g['keys']):
                    continue
                if e['year'] and g['year'] and e['year'] != g['year']:
                    continue
                target = g
                break
            if target is None:
                target = {'keys': set(), 'entries': {}, 'year': None, 'rank': rank}
                groups.append(target)
                rank += 1
            target['keys'] |= keys
            target['entries'][src] = e
            target['year'] = target['year'] or e['year']

    # Phim có mặt ở nhiều nguồn lên trước; cùng số nguồn thì giữ thứ tự gốc.
    groups.sort(key=lambda g: (-len(g['entries']), g['rank']))
    return groups


# ============================================================
# HIỂN THỊ
# ============================================================

def _badges(group):
    return ' '.join(
        f'[COLOR {SOURCES[s][2]}]{SOURCES[s][1]}[/COLOR]'
        for s in ORDER if s in group['entries']
    )


def _group_listitem(group):
    entries = group['entries']
    first = entries[next(s for s in ORDER if s in entries)]
    name = first['name'] or first['origin']
    origin = next((e['origin'] for e in entries.values() if e['origin']), '')
    year = group['year']
    tags = next((e['tags'] for e in entries.values() if e['tags']), '')

    label = f'{name} ({year})' if year else name
    if tags:
        label += f' [COLOR yellow]({tags})[/COLOR]'
    label += f'  {_badges(group)}'

    plot = max((e['plot'] for e in entries.values()), key=len, default='')
    srcs = ', '.join(SOURCES[s][0] for s in ORDER if s in entries)
    head = ' | '.join(t for t in (origin, f'Nguồn: {srcs}') if t)
    plot = f'{head}\n\n{plot}' if plot else head

    poster = next((e['poster'] for e in entries.values()
                   if e['poster'] and e['poster'] != 'DefaultVideo.png'), first['poster'])
    thumb = next((e['thumb'] for e in entries.values()
                  if e['thumb'] and e['thumb'] != 'DefaultVideo.png'), first['thumb'])

    item = Listitem()
    item.label = label
    item.info['plot'] = plot
    item.info['mediatype'] = 'tvshow'
    if year:
        item.info['year'] = year
    if origin:
        item.info['originaltitle'] = origin
    item.art['thumb'] = thumb
    item.art['poster'] = poster

    if len(entries) == 1:
        src = next(iter(entries))
        item.set_callback(SOURCES[src][3], entries[src]['slug'])
    else:
        pairs = json.dumps(
            [[s, entries[s]['slug']] for s in ORDER if s in entries]
        )
        item.set_callback(chi_tiet_gop, name, pairs)
    return item


@Route.register
def chi_tiet_gop(plugin, name, pairs):
    """Phim có ở nhiều nguồn: cho chọn nguồn để xem danh sách tập."""
    for src, slug in json.loads(pairs):
        item = Listitem()
        item.label = (
            f'[COLOR {SOURCES[src][2]}][B]{SOURCES[src][0]}[/B][/COLOR]'
            f' - {name}'
        )
        item.info['plot'] = f'Xem "{name}" từ nguồn {SOURCES[src][0]}'
        item.set_callback(SOURCES[src][3], slug)
        yield item


# ============================================================
# TÌM KIẾM
# ============================================================

@Route.register
def tim_kiem_dialog(plugin):
    keyboard = Keyboard('Tìm kiếm phim (KKPhim + NguonC + VSMOV)')
    try:
        keyboard.setDefault('')
        keyboard.setText('')
    except Exception:
        pass
    keyboard.doModal()

    if keyboard.isConfirmed():
        query = keyboard.getText().strip()
        if query:
            yield from tim_kiem(plugin, query)
            return
    yield Listitem()


@Route.register
def tim_kiem(plugin, search_query):
    if not search_query:
        return
    save_search_history(search_query)

    results, failed = search_all(search_query)
    groups = merge_results(results)

    for g in groups:
        yield _group_listitem(g)

    if not groups:
        item = Listitem()
        if len(failed) == len(ORDER):
            item.label = 'Không kết nối được nguồn nào (xem log Kodi)'
        else:
            item.label = f'Không tìm thấy phim nào cho "{search_query}"'
        yield item

    if failed and len(failed) < len(ORDER):
        item = Listitem()
        names = ', '.join(SOURCES[s][0] for s in failed)
        item.label = f'[COLOR red]Không tải được: {names}[/COLOR]'
        yield item


# ============================================================
# LỊCH SỬ TÌM KIẾM (dùng chung cho cả 3 nguồn)
# ============================================================

def _history_path():
    folder = os.path.join(translatePath('special://userdata/addon_data'), ADDON_ID)
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, HISTORY_FILE)


def get_search_history():
    try:
        with open(_history_path(), 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _write_history(data):
    try:
        with open(_history_path(), 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        Script.log(f'[TimPhim] Lỗi ghi lịch sử: {e}')


def save_search_history(keyword):
    history = [h for h in get_search_history() if h != keyword]
    history.insert(0, keyword)
    _write_history(history[:MAX_HISTORY])


@Route.register
def lich_su_tim_kiem(plugin):
    history = get_search_history()

    clear_item = Listitem()
    clear_item.label = '[B]XÓA TOÀN BỘ LỊCH SỬ[/B]'
    clear_item.set_callback(xoa_lich_su_tim_kiem)
    yield clear_item

    if not history:
        item = Listitem()
        item.label = 'Chưa có lịch sử tìm kiếm'
        yield item
        return

    for keyword in history:
        item = Listitem()
        item.label = keyword
        item.set_callback(tim_kiem, keyword)
        yield item


@Route.register
def xoa_lich_su_tim_kiem(plugin):
    _write_history([])
    executebuiltin('Container.Refresh()')
    yield Listitem()
