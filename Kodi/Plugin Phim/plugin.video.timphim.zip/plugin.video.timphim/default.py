from codequick import Route, Listitem, run

from resources.lib import search
from resources.lib.kk.utils import setup_kodi_cache


@Route.register
def root(plugin):
    """Menu chính: tìm kiếm gộp KKPhim + NguonC + VSMOV."""
    setup_kodi_cache()

    item = Listitem()
    item.label = '[B]TÌM KIẾM (KKPhim + NguonC + VSMOV)[/B]'
    item.set_callback(search.tim_kiem_dialog)
    yield item

    if search.get_search_history():
        item = Listitem()
        item.label = '[B]LỊCH SỬ TÌM KIẾM[/B]'
        item.set_callback(search.lich_su_tim_kiem)
        yield item


if __name__ == '__main__':
    run()
