import re
from html import unescape
from urllib.parse import quote

from codequick import Route, Listitem, Resolver, Script
from resources.lib.utils import (
    get_json, stream, fix_image,
    read_json_file, write_json_file,
    save_resume_position, get_resume_position,
    BASE_API, BASE_WEB, USER_AGENT,
)
from xbmc import Keyboard, executebuiltin, Player, Monitor

TRANSPARENT_ICON = (
    'https://upload.wikimedia.org/wikipedia/commons/c/ca/1x1.png'
)

# Slug thể loại / quốc gia. API không có endpoint liệt kê nên khai báo sẵn.
# Slug không tồn tại sẽ trả 404 và add-on hiển thị "Không có phim".
THE_LOAI = [
    ('Hành Động', 'hanh-dong'), ('Phiêu Lưu', 'phieu-luu'),
    ('Hoạt Hình', 'hoat-hinh'), ('Hài Hước', 'hai-huoc'),
    ('Hình Sự', 'hinh-su'), ('Tài Liệu', 'tai-lieu'),
    ('Chính Kịch', 'chinh-kich'), ('Gia Đình', 'gia-dinh'),
    ('Giả Tưởng', 'gia-tuong'), ('Lịch Sử', 'lich-su'),
    ('Kinh Dị', 'kinh-di'), ('Nhạc', 'nhac'),
    ('Bí Ẩn', 'bi-an'), ('Lãng Mạn', 'lang-man'),
    ('Khoa Học Viễn Tưởng', 'khoa-hoc-vien-tuong'),
    ('Gây Cấn', 'gay-can'), ('Chiến Tranh', 'chien-tranh'),
    ('Tâm Lý', 'tam-ly'), ('Tình Cảm', 'tinh-cam'),
    ('Cổ Trang', 'co-trang'), ('Miền Tây', 'mien-tay'),
    ('Thần Thoại', 'than-thoai'), ('Học Đường', 'hoc-duong'),
    ('Kinh Điển', 'kinh-dien'), ('Thể Thao', 'the-thao'),
    ('Võ Thuật', 'vo-thuat'),
]

QUOC_GIA = [
    ('Việt Nam', 'viet-nam'), ('Trung Quốc', 'trung-quoc'),
    ('Hàn Quốc', 'han-quoc'), ('Nhật Bản', 'nhat-ban'),
    ('Thái Lan', 'thai-lan'), ('Âu Mỹ', 'au-my'),
    ('Đài Loan', 'dai-loan'), ('Hồng Kông', 'hong-kong'),
    ('Ấn Độ', 'an-do'), ('Anh', 'anh'), ('Pháp', 'phap'),
    ('Canada', 'canada'), ('Đức', 'duc'), ('Tây Ban Nha', 'tay-ban-nha'),
    ('Thổ Nhĩ Kỳ', 'tho-nhi-ky'), ('Hà Lan', 'ha-lan'),
    ('Indonesia', 'indonesia'), ('Nga', 'nga'), ('Mexico', 'mexico'),
    ('Ba Lan', 'ba-lan'), ('Úc', 'uc'), ('Thụy Điển', 'thuy-dien'),
    ('Malaysia', 'malaysia'), ('Brazil', 'brazil'),
    ('Philippines', 'philippines'), ('Bồ Đào Nha', 'bo-dao-nha'),
    ('Ý', 'y'), ('Đan Mạch', 'dan-mach'), ('UAE', 'uae'),
    ('Na Uy', 'na-uy'), ('Thụy Sĩ', 'thuy-si'), ('Châu Phi', 'chau-phi'),
    ('Ả Rập Xê Út', 'a-rap-xe-ut'), ('Nam Phi', 'nam-phi'),
    ('Ukraina', 'ukraina'), ('Quốc Gia Khác', 'quoc-gia-khac'),
]


# ============================================================
# TIỆN ÍCH
# ============================================================

def _clean_html(text):
    text = unescape(text or '')
    return re.sub(r'<[^>]+>', '', text).strip()


def _api(path, params=None):
    return get_json(f'{BASE_API}/{path}', params)


def _empty(label):
    item = Listitem()
    item.label = label
    item.art['thumb'] = TRANSPARENT_ICON
    return item


def _extract_list(data):
    """Trả về (items, total_page) từ phản hồi dạng danh sách.

    Hỗ trợ cả hai dạng: {items, paginate} và {data: {items, paginate}}.
    """
    if not isinstance(data, dict):
        return [], 1
    root = data.get('data') if isinstance(data.get('data'), dict) else data
    items = root.get('items') or data.get('items') or []
    paginate = root.get('paginate') or data.get('paginate') or {}
    try:
        total_page = int(paginate.get('total_page') or 1)
    except (TypeError, ValueError):
        total_page = 1
    return (items if isinstance(items, list) else []), total_page


def _movie_listitem(m):
    slug = m.get('slug')
    if not slug:
        return None

    name = m.get('name') or m.get('original_name') or slug
    quality = (m.get('quality') or '').strip()
    current = (m.get('current_episode') or '').strip()

    label = name
    tags = ' | '.join(t for t in (quality, current) if t)
    if tags:
        label = f'{name} [COLOR yellow]({tags})[/COLOR]'

    plot_head = ' | '.join(
        t for t in (m.get('original_name'), m.get('language')) if t
    )
    plot = _clean_html(m.get('description'))
    if plot_head:
        plot = f'{plot_head}\n\n{plot}' if plot else plot_head

    poster = fix_image(m.get('poster_url') or m.get('thumb_url'))
    thumb = fix_image(m.get('thumb_url') or m.get('poster_url'))

    item = Listitem()
    item.label = label
    item.info['plot'] = plot or f'Phim: {name}'
    item.info['mediatype'] = 'tvshow'
    item.art['thumb'] = thumb
    item.art['poster'] = poster
    item.set_callback(chi_tiet, slug)
    return item


def _render_page(path, page, params=None, empty_label='Không có phim'):
    """Gọi API danh sách, yield phim và nút trang kế tiếp."""
    query = {'page': page}
    if params:
        query.update(params)
    data = _api(path, query)
    items, total_page = _extract_list(data)

    if not items:
        yield _empty(empty_label)
        return

    for m in items:
        li = _movie_listitem(m)
        if li:
            yield li

    if page < total_page:
        yield None  # đánh dấu: caller tự thêm nút trang kế tiếp


# ============================================================
# DANH SÁCH CHUNG (phim mới, phim lẻ, phim bộ, thể loại, ...)
# ============================================================

@Route.register
def danh_sach(plugin, path, page=1):
    page = int(page)
    for li in _render_page(path, page):
        if li is None:
            nxt = Listitem()
            nxt.label = f'Trang {page + 1} >>'
            nxt.art['thumb'] = TRANSPARENT_ICON
            nxt.set_callback(danh_sach, path, page + 1)
            yield nxt
        else:
            yield li


# ============================================================
# THỂ LOẠI / QUỐC GIA / NĂM
# ============================================================

@Route.register
def the_loai(plugin):
    for name, slug in THE_LOAI:
        item = Listitem()
        item.label = name
        item.art['thumb'] = TRANSPARENT_ICON
        item.set_callback(danh_sach, f'films/the-loai/{slug}', 1)
        yield item


@Route.register
def quoc_gia(plugin):
    for name, slug in QUOC_GIA:
        item = Listitem()
        item.label = name
        item.art['thumb'] = TRANSPARENT_ICON
        item.set_callback(danh_sach, f'films/quoc-gia/{slug}', 1)
        yield item


NGON_NGU = [
    ('Vietsub', 'vietsub'),
    ('Thuyết Minh', 'thuyet-minh'),
    ('Lồng Tiếng', 'long-tieng'),
]


@Route.register
def ngon_ngu(plugin):
    for name, slug in NGON_NGU:
        item = Listitem()
        item.label = name
        item.art['thumb'] = TRANSPARENT_ICON
        item.set_callback(danh_sach, f'films/ngon-ngu/{slug}', 1)
        yield item


@Route.register
def nam_phat_hanh(plugin, current_year):
    current_year = int(current_year)
    for year in range(current_year, 1999, -1):
        item = Listitem()
        item.label = str(year)
        item.art['thumb'] = TRANSPARENT_ICON
        item.set_callback(danh_sach, f'films/nam-phat-hanh/{year}', 1)
        yield item


# ============================================================
# TÌM KIẾM
# ============================================================

@Route.register
def tim_kiem_dialog(plugin):
    """Mở dialog nhập từ khóa — luôn bắt đầu với text rỗng."""
    keyboard = Keyboard('Tìm kiếm phim')
    try:
        keyboard.setDefault('')
        keyboard.setText('')
    except Exception:
        pass

    keyboard.doModal()

    if keyboard.isConfirmed():
        query = keyboard.getText().strip()
        if query:
            yield from tim_kiem(plugin, query)
        else:
            yield Listitem()
    else:
        yield Listitem()


@Route.register
def tim_kiem(plugin, search_query, page=1):
    if not search_query:
        return
    page = int(page)
    if page == 1:
        save_search_history(search_query)

    # requests tự mã hóa tham số keyword
    for li in _render_page(
        'films/search', page, {'keyword': search_query},
        f'Không tìm thấy phim nào cho "{search_query}"',
    ):
        if li is None:
            nxt = Listitem()
            nxt.label = f'Trang {page + 1} >>'
            nxt.art['thumb'] = TRANSPARENT_ICON
            nxt.set_callback(tim_kiem, search_query, page + 1)
            yield nxt
        else:
            yield li


# ============================================================
# CHI TIẾT PHIM + TẬP PHIM (resume theo server)
# ============================================================

def _ep_label(ep_name):
    ep_name = (ep_name or '').strip()
    if ep_name.isdigit():
        return f'Tập {ep_name}'
    return ep_name or 'Tập ?'


@Route.register
def chi_tiet(plugin, slug):
    yield []

    data = _api(f'film/{quote(slug, safe="")}')
    if not isinstance(data, dict):
        yield _empty('Không tải được thông tin phim')
        return

    movie = data.get('movie') if isinstance(data.get('movie'), dict) else data
    episodes = movie.get('episodes') or data.get('episodes') or []

    name = movie.get('name', '')
    origin_name = movie.get('original_name', '')
    poster = fix_image(movie.get('poster_url') or movie.get('thumb_url'))
    thumb = fix_image(movie.get('thumb_url') or movie.get('poster_url'))
    content = _clean_html(movie.get('description'))

    shown = 0
    for server in episodes:
        server_name = (server.get('server_name') or 'Server').strip()
        for ep in server.get('items') or server.get('server_data') or []:
            link = ep.get('m3u8') or ep.get('link_m3u8') or ''
            if not link:
                continue

            ep_name = (ep.get('name') or '').strip()
            resume_pos, _ = get_resume_position(slug, ep_name, server_name)
            label_ep = _ep_label(ep_name)

            item = Listitem()
            if resume_pos > 0:
                item.label = (
                    f'[{server_name}] {label_ep} '
                    f'[COLOR yellow]>> Xem tiếp '
                    f'{resume_pos // 60}:{resume_pos % 60:02d}[/COLOR]'
                )
            else:
                item.label = f'[{server_name}] {label_ep}'

            item.info['mediatype'] = 'episode'
            item.info['plot'] = content
            item.info['tvshowtitle'] = name
            item.info['originaltitle'] = origin_name
            item.art['thumb'] = thumb
            item.art['poster'] = poster
            item.set_callback(
                play_nguonc, link, f'{name} - {label_ep}',
                slug, ep_name, resume_pos, server_name,
            )
            yield item
            shown += 1

    if not shown:
        item = _empty('Phim chưa có tập hoặc chỉ có trailer')
        item.info['plot'] = content
        item.art['poster'] = poster
        yield item


# ============================================================
# RESOLVER - PHÁT VIDEO
# ============================================================

@Resolver.register
def play_nguonc(plugin, url, title, movie_slug='', episode_name='',
                resume_pos=0, server_name=''):
    save_watch_history(title, url)

    item = Listitem()
    item.label = title
    item.path = stream(url)

    item.property['inputstream'] = 'inputstream.ffmpegdirect'
    item.property['inputstream.ffmpegdirect.manifest_type'] = 'hls'
    item.property['inputstream.ffmpegdirect.stream_headers'] = (
        f'User-Agent={USER_AGENT}&Referer={BASE_WEB}/'
    )
    item.property['inputstream.ffmpegdirect.manifest_headers'] = (
        item.property['inputstream.ffmpegdirect.stream_headers']
    )

    if movie_slug and episode_name:
        _start_resume_tracker(
            movie_slug, episode_name, int(resume_pos or 0), server_name
        )

    return item


def _start_resume_tracker(movie_slug, episode_name, start_pos=0,
                          server_name=''):
    import threading
    import time

    def tracker():
        monitor = Monitor()
        player = Player()

        time.sleep(5)

        if start_pos > 0:
            try:
                waited = 0
                while not player.isPlayingVideo() and waited < 15:
                    time.sleep(1)
                    waited += 1
                if player.isPlayingVideo():
                    player.seekTime(float(start_pos))
                    time.sleep(2)
            except Exception as e:
                Script.log(f'[NguonC] Lỗi seek: {e}')

        last_save = 0
        no_video_count = 0

        while not monitor.abortRequested():
            if player.isPlayingVideo():
                no_video_count = 0
                try:
                    pos = player.getTime()
                    total = player.getTotalTime()
                    now = time.time()
                    if now - last_save >= 10 and total > 30 and pos > 0:
                        save_resume_position(
                            movie_slug, episode_name, pos, total, server_name
                        )
                        last_save = now
                except Exception as e:
                    Script.log(f'[NguonC] Lỗi tracker: {e}')
            else:
                no_video_count += 1
                if no_video_count >= 5:
                    try:
                        pos = player.getTime()
                        total = player.getTotalTime()
                        if total > 30 and pos > 0:
                            save_resume_position(
                                movie_slug, episode_name, pos, total,
                                server_name
                            )
                    except Exception:
                        pass
                    break

            time.sleep(1)

    threading.Thread(target=tracker, daemon=True).start()


# ============================================================
# LỊCH SỬ TÌM KIẾM
# ============================================================

HISTORY_FILE = 'search_history.json'
MAX_HISTORY = 20


def save_search_history(keyword):
    if not keyword:
        return
    history = read_json_file(HISTORY_FILE, [])
    if keyword in history:
        history.remove(keyword)
    history.insert(0, keyword)
    write_json_file(HISTORY_FILE, history[:MAX_HISTORY])


def lich_su_tim_kiem_menu():
    if not read_json_file(HISTORY_FILE, []):
        return
    item = Listitem()
    item.label = '[B]LỊCH SỬ TÌM KIẾM[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(lich_su_tim_kiem)
    yield item


@Route.register
def lich_su_tim_kiem(plugin):
    history = read_json_file(HISTORY_FILE, [])

    clear_item = Listitem()
    clear_item.label = '[B]XÓA TOÀN BỘ LỊCH SỬ[/B]'
    clear_item.art['thumb'] = TRANSPARENT_ICON
    clear_item.set_callback(xoa_lich_su_tim_kiem)
    yield clear_item

    if not history:
        yield _empty('Chưa có lịch sử tìm kiếm')
        return

    for keyword in history:
        item = Listitem()
        item.label = keyword
        item.art['thumb'] = TRANSPARENT_ICON
        item.set_callback(tim_kiem, keyword)
        yield item


@Route.register
def xoa_lich_su_tim_kiem(plugin):
    write_json_file(HISTORY_FILE, [])
    executebuiltin('Container.Refresh()')
    yield Listitem()


# ============================================================
# LỊCH SỬ XEM PHIM
# ============================================================

WATCH_FILE = 'watch_history.json'
MAX_WATCH = 20


def save_watch_history(title, url):
    if not title or not url:
        return
    history = read_json_file(WATCH_FILE, [])
    history = [h for h in history if h.get('title') != title]
    history.insert(0, {'title': title, 'url': url})
    write_json_file(WATCH_FILE, history[:MAX_WATCH])


def lich_su_xem_phim_menu():
    if not read_json_file(WATCH_FILE, []):
        return
    item = Listitem()
    item.label = '[B]LỊCH SỬ XEM PHIM[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(lich_su_xem_phim)
    yield item


@Route.register
def lich_su_xem_phim(plugin):
    history = read_json_file(WATCH_FILE, [])

    clear_item = Listitem()
    clear_item.label = '[B]XÓA TOÀN BỘ LỊCH SỬ[/B]'
    clear_item.art['thumb'] = TRANSPARENT_ICON
    clear_item.set_callback(xoa_lich_su_xem_phim)
    yield clear_item

    if not history:
        yield _empty('Chưa có lịch sử xem phim')
        return

    for entry in history:
        title = entry.get('title', '')
        url = entry.get('url', '')
        if not title or not url:
            continue
        item = Listitem()
        item.label = title
        item.art['thumb'] = TRANSPARENT_ICON
        item.info['mediatype'] = 'episode'
        item.set_callback(play_nguonc, url, title)
        yield item


@Route.register
def xoa_lich_su_xem_phim(plugin):
    write_json_file(WATCH_FILE, [])
    executebuiltin('Container.Refresh()')
    yield Listitem()
