import json
import re
from html import unescape
from urllib.parse import quote, urljoin, urlparse

import requests
from codequick import Route, Listitem, Resolver, Script
from resources.lib.utils import (
    get_json, fix_image,
    read_json_file, write_json_file,
    save_resume_position, get_resume_position,
    BASE_API, BASE_WEB, USER_AGENT,
)
from xbmc import Keyboard, executebuiltin, Player, Monitor

TRANSPARENT_ICON = (
    'https://upload.wikimedia.org/wikipedia/commons/c/ca/1x1.png'
)

IOS_UA = (
    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) '
    'AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 '
    'Mobile/15E148 Safari/604.1'
)

THE_LOAI = [
    ('Hành Động', 'hanh-dong'), ('Phiêu Lưu', 'phieu-luu'),
    ('Hoạt Hình', 'hoat-hinh'), ('Hài Hước', 'hai-huoc'),
    ('Hình Sự', 'hinh-su'), ('Tài Liệu', 'tai-lieu'),
    ('Chính Kịch', 'chinh-kich'), ('Gia Đình', 'gia-dinh'),
    ('Giả Tưởng', 'gia-tuong'), ('Lịch Sử', 'lich-su'),
    ('Kinh Dị', 'kinh-di'), ('Nhạc', 'nhac'),
    ('Bí Ẩn', 'bi-an'), ('Lãng Mạn', 'lang-man'),
    ('Khoa Học Viễn Tưởng', 'khoa-hoc-vien-tuong'),
    ('Gây Cấn', 'gay-can'), ('Chiến Tranh', 'chien-tranh'),
    ('Tâm Lý', 'tam-ly'), ('Tình Cảm', 'tinh-cam'),
    ('Cổ Trang', 'co-trang'), ('Miền Tây', 'mien-tay'),
    ('Thần Thoại', 'than-thoai'), ('Học Đường', 'hoc-duong'),
    ('Kinh Điển', 'kinh-dien'), ('Thể Thao', 'the-thao'),
    ('Võ Thuật', 'vo-thuat'),
]

QUOC_GIA = [
    ('Việt Nam', 'viet-nam'), ('Trung Quốc', 'trung-quoc'),
    ('Hàn Quốc', 'han-quoc'), ('Nhật Bản', 'nhat-ban'),
    ('Thái Lan', 'thai-lan'), ('Âu Mỹ', 'au-my'),
    ('Đài Loan', 'dai-loan'), ('Hồng Kông', 'hong-kong'),
    ('Ấn Độ', 'an-do'), ('Anh', 'anh'), ('Pháp', 'phap'),
    ('Canada', 'canada'), ('Đức', 'duc'), ('Tây Ban Nha', 'tay-ban-nha'),
    ('Thổ Nhĩ Kỳ', 'tho-nhi-ky'), ('Hà Lan', 'ha-lan'),
    ('Indonesia', 'indonesia'), ('Nga', 'nga'), ('Mexico', 'mexico'),
    ('Ba Lan', 'ba-lan'), ('Úc', 'uc'), ('Thụy Điển', 'thuy-dien'),
    ('Malaysia', 'malaysia'), ('Brazil', 'brazil'),
    ('Philippines', 'philippines'), ('Bồ Đào Nha', 'bo-dao-nha'),
    ('Ý', 'y'), ('Đan Mạch', 'dan-mach'), ('UAE', 'uae'),
    ('Na Uy', 'na-uy'), ('Thụy Sĩ', 'thuy-si'), ('Châu Phi', 'chau-phi'),
    ('Ả Rập Xê Út', 'a-rap-xe-ut'), ('Nam Phi', 'nam-phi'),
    ('Ukraina', 'ukraina'), ('Quốc Gia Khác', 'quoc-gia-khac'),
]

NGON_NGU = [
    ('Vietsub', 'vietsub'),
    ('Thuyết Minh', 'thuyet-minh'),
    ('Lồng Tiếng', 'long-tieng'),
]


# ============================================================
# TIỆN ÍCH
# ============================================================

def _clean_html(text):
    text = unescape(text or '')
    return re.sub(r'<[^>]+>', '', text).strip()


def _api(path, params=None):
    return get_json(f'{BASE_API}/{path}', params)


def _empty(label):
    item = Listitem()
    item.label = label
    item.art['thumb'] = TRANSPARENT_ICON
    return item


def _extract_list(data):
    """Trả về (items, total_page) từ phản hồi dạng danh sách."""
    if not isinstance(data, dict):
        return [], 1
    root = data.get('data') if isinstance(data.get('data'), dict) else data
    items = root.get('items') or data.get('items') or []
    paginate = root.get('paginate') or data.get('paginate') or {}
    try:
        total_page = int(paginate.get('total_page') or 1)
    except (TypeError, ValueError):
        total_page = 1
    return (items if isinstance(items, list) else []), total_page


def _movie_listitem(m):
    slug = m.get('slug')
    if not slug:
        return None

    name = m.get('name') or m.get('original_name') or slug
    quality = (m.get('quality') or '').strip()
    current = (m.get('current_episode') or '').strip()

    label = name
    tags = ' | '.join(t for t in (quality, current) if t)
    if tags:
        label = f'{name} [COLOR yellow]({tags})[/COLOR]'

    plot_head = ' | '.join(
        t for t in (m.get('original_name'), m.get('language')) if t
    )
    plot = _clean_html(m.get('description'))
    if plot_head:
        plot = f'{plot_head}\n\n{plot}' if plot else plot_head

    poster = fix_image(m.get('poster_url') or m.get('thumb_url'))
    thumb = fix_image(m.get('thumb_url') or m.get('poster_url'))

    item = Listitem()
    item.label = label
    item.info['plot'] = plot or f'Phim: {name}'
    item.info['mediatype'] = 'tvshow'
    item.art['thumb'] = thumb
    item.art['poster'] = poster
    item.set_callback(chi_tiet, slug)
    return item


def _render_page(path, page, params=None, empty_label='Không có phim'):
    """Gọi API danh sách, yield phim và nút trang kế tiếp."""
    query = {'page': page}
    if params:
        query.update(params)
    data = _api(path, query)
    items, total_page = _extract_list(data)

    if not items:
        yield _empty(empty_label)
        return

    for m in items:
        li = _movie_listitem(m)
        if li:
            yield li

    if page < total_page:
        yield None


# ============================================================
# DANH SÁCH CHUNG
# ============================================================

@Route.register
def danh_sach(plugin, path, page=1):
    page = int(page)
    for li in _render_page(path, page):
        if li is None:
            nxt = Listitem()
            nxt.label = f'Trang {page + 1} >>'
            nxt.art['thumb'] = TRANSPARENT_ICON
            nxt.set_callback(danh_sach, path, page + 1)
            yield nxt
        else:
            yield li


# ============================================================
# THỂ LOẠI / QUỐC GIA / NGÔN NGỮ / NĂM
# ============================================================

@Route.register
def the_loai(plugin):
    for name, slug in THE_LOAI:
        item = Listitem()
        item.label = name
        item.art['thumb'] = TRANSPARENT_ICON
        item.set_callback(danh_sach, f'films/the-loai/{slug}', 1)
        yield item


@Route.register
def quoc_gia(plugin):
    for name, slug in QUOC_GIA:
        item = Listitem()
        item.label = name
        item.art['thumb'] = TRANSPARENT_ICON
        item.set_callback(danh_sach, f'films/quoc-gia/{slug}', 1)
        yield item


@Route.register
def ngon_ngu(plugin):
    for name, slug in NGON_NGU:
        item = Listitem()
        item.label = name
        item.art['thumb'] = TRANSPARENT_ICON
        item.set_callback(danh_sach, f'films/ngon-ngu/{slug}', 1)
        yield item


@Route.register
def nam_phat_hanh(plugin, current_year):
    current_year = int(current_year)
    for year in range(current_year, 1999, -1):
        item = Listitem()
        item.label = str(year)
        item.art['thumb'] = TRANSPARENT_ICON
        item.set_callback(danh_sach, f'films/nam-phat-hanh/{year}', 1)
        yield item


# ============================================================
# TÌM KIẾM
# ============================================================

@Route.register
def tim_kiem_dialog(plugin):
    """Mở dialog nhập từ khóa."""
    keyboard = Keyboard('Tìm kiếm phim')
    try:
        keyboard.setDefault('')
        keyboard.setText('')
    except Exception:
        pass

    keyboard.doModal()

    if keyboard.isConfirmed():
        query = keyboard.getText().strip()
        if query:
            yield from tim_kiem(plugin, query)
        else:
            yield Listitem()
    else:
        yield Listitem()


@Route.register
def tim_kiem(plugin, search_query, page=1):
    if not search_query:
        return
    page = int(page)
    if page == 1:
        save_search_history(search_query)

    for li in _render_page(
        'films/search', page, {'keyword': search_query},
        f'Không tìm thấy phim nào cho "{search_query}"',
    ):
        if li is None:
            nxt = Listitem()
            nxt.label = f'Trang {page + 1} >>'
            nxt.art['thumb'] = TRANSPARENT_ICON
            nxt.set_callback(tim_kiem, search_query, page + 1)
            yield nxt
        else:
            yield li


# ============================================================
# CHI TIẾT PHIM + TẬP PHIM
# ============================================================

def _ep_label(ep_name):
    ep_name = (ep_name or '').strip()
    if ep_name.isdigit():
        return f'Tập {ep_name}'
    return ep_name or 'Tập ?'


def _servers(movie, data):
    eps = movie.get('episodes') or data.get('episodes') or []
    if isinstance(eps, dict):
        eps = list(eps.values())
    return [e for e in eps if isinstance(e, dict)]


def _server_items(server):
    items = (server.get('items') or server.get('server_data')
             or server.get('episodes') or [])
    if isinstance(items, dict):
        items = list(items.values())
    return [i for i in items if isinstance(i, dict)]


def _pick_link(ep):
    """Ưu tiên link .m3u8; không có thì lấy link embed."""
    for key in ('m3u8', 'link_m3u8', 'hls', 'file', 'url', 'link'):
        v = ep.get(key)
        if isinstance(v, str) and v.startswith('http'):
            return v
    for v in ep.values():
        if isinstance(v, str) and '.m3u8' in v and v.startswith('http'):
            return v
    for key in ('embed', 'link_embed'):
        v = ep.get(key)
        if isinstance(v, str) and v.startswith('http'):
            return v
    return ''


@Route.register
def chi_tiet(plugin, slug):
    yield []

    data = _api(f'film/{quote(slug, safe="")}')
    if not isinstance(data, dict):
        yield _empty('Không tải được thông tin phim (xem log Kodi)')
        return

    movie = data.get('movie') if isinstance(data.get('movie'), dict) else data

    name = movie.get('name', '')
    origin_name = movie.get('original_name', '')
    poster = fix_image(movie.get('poster_url') or movie.get('thumb_url'))
    thumb = fix_image(movie.get('thumb_url') or movie.get('poster_url'))
    content = _clean_html(movie.get('description'))

    shown = 0
    for server in _servers(movie, data):
        server_name = (server.get('server_name') or 'Server').strip()
        for ep in _server_items(server):
            link = _pick_link(ep)
            if not link:
                continue

            ep_name = (ep.get('name') or '').strip()
            resume_pos, _ = get_resume_position(slug, ep_name, server_name)
            label_ep = _ep_label(ep_name)

            item = Listitem()
            if resume_pos > 0:
                item.label = (
                    f'[{server_name}] {label_ep} '
                    f'[COLOR yellow]>> Xem tiếp '
                    f'{resume_pos // 60}:{resume_pos % 60:02d}[/COLOR]'
                )
            else:
                item.label = f'[{server_name}] {label_ep}'

            item.info['mediatype'] = 'episode'
            item.info['plot'] = content
            item.info['tvshowtitle'] = name
            item.info['originaltitle'] = origin_name
            item.art['thumb'] = thumb
            item.art['poster'] = poster
            item.set_callback(
                play_nguonc, link, f'{name} - {label_ep}',
                slug, ep_name, resume_pos, server_name,
            )
            yield item
            shown += 1

    if not shown:
        item = _empty('Không tìm thấy link phát')
        item.info['plot'] = content
        item.art['poster'] = poster
        yield item


# ============================================================
# RESOLVER - GIẢI MÃ VÀ PHÁT VIDEO
# ============================================================

M3U8_RE = re.compile(r'https?://[^"\'\s<>\\]+?\.m3u8[^"\'\s<>\\]*')


def _norm(text):
    return (text.replace('\\/', '/').replace('\\u0026', '&')
            .replace('&amp;', '&'))


def _find_m3u8(text):
    m = M3U8_RE.search(_norm(text or ''))
    return m.group(0) if m else ''


def _origin(url):
    p = urlparse(url)
    return f'{p.scheme}://{p.netloc}'


def _abs(base_url, link):
    return urljoin(base_url, _norm(link))


def _resolve_embed(url):
    """Giải mã luồng phát từ trang embed của NguonC (streamc.xyz)."""
    if '.m3u8' in url and 'embed.php' not in url:
        return url, f'User-Agent={USER_AGENT}&Referer={BASE_WEB}/'

    origin = _origin(url)
    ios_headers = f'User-Agent={IOS_UA}&Origin={origin}&Referer={origin}/'

    req_headers = {
        'User-Agent': IOS_UA,
        'Referer': f'{BASE_WEB}/',
        'Origin': origin,
    }

    try:
        r = requests.get(url, timeout=15, headers=req_headers)
        page = r.text
    except Exception as e:
        Script.log(f'[NguonC] Lỗi mở embed {url}: {e}')
        return '', ''

    # 1. Lấy cấu hình từ thẻ <script id="stream-bootstrap">
    m = re.search(
        r'<script[^>]*id="stream-bootstrap"[^>]*>(.*?)</script>',
        page, re.S
    )
    if not m:
        found = _find_m3u8(page)
        return (_abs(url, found), ios_headers) if found else ('', '')

    try:
        boot_cfg = json.loads(m.group(1))
    except Exception as e:
        Script.log(f'[NguonC] Lỗi parse JSON stream-bootstrap: {e}')
        return '', ''

    api_url = boot_cfg.get('api') or url
    post_headers = {
        'User-Agent': IOS_UA,
        'Content-Type': 'application/json',
        'Origin': origin,
        'Referer': url,
    }

    # 2. Gọi action="bootstrap" nếu chưa có sẵn token bootstrap
    if not boot_cfg.get('bootstrap'):
        payload_boot = {
            'action': 'bootstrap',
            'referrer': f'{BASE_WEB}/',
            'frame_origins': [BASE_WEB],
            'request_grant': True,
            'playlist_format': 'hls',
            'pretty_url': True,
            'path_chunks': True,
            'bootstrap_format': 'json',
        }
        try:
            rb = requests.post(
                api_url, json=payload_boot, headers=post_headers, timeout=15
            )
            if not rb.ok:
                Script.log(
                    f'[NguonC] Bootstrap HTTP {rb.status_code}: {rb.text[:300]}'
                )
                return '', ''
            boot_cfg = rb.json()
        except Exception as e:
            Script.log(f'[NguonC] Lỗi gọi action=bootstrap: {e}')
            return '', ''

    # Nếu server đã cấp sẵn link playlist trong preissued
    preissued = boot_cfg.get('preissued')
    if isinstance(preissued, dict) and preissued.get('playlist'):
        Script.log(
            f'[NguonC] Lấy được preissued playlist: {preissued["playlist"]}'
        )
        return preissued['playlist'], ios_headers

    if boot_cfg.get('turnstileEnabled'):
        Script.log(
            '[NguonC] Server yêu cầu Cloudflare Turnstile (Captcha), '
            'không thể vượt qua tự động.'
        )
        return '', ''

    bootstrap_token = boot_cfg.get('bootstrap')
    if not bootstrap_token:
        Script.log(f'[NguonC] Thiếu bootstrap token: {boot_cfg}')
        return '', ''

    # 3. Gọi action="issue" để lấy URL playlist (.m3u8)
    payload_issue = {
        'action': 'issue',
        'bootstrap': bootstrap_token,
        'turnstile_response': '',
        'playlist_format': 'hls',
        'pretty_url': True,
        'path_chunks': True,
        'frame_origins': [BASE_WEB],
    }
    try:
        ri = requests.post(
            api_url, json=payload_issue, headers=post_headers, timeout=15
        )
        if not ri.ok:
            Script.log(
                f'[NguonC] Issue HTTP {ri.status_code}: {ri.text[:300]}'
            )
            return '', ''
        issue_data = ri.json()
    except Exception as e:
        Script.log(f'[NguonC] Lỗi gọi action=issue: {e}')
        return '', ''

    playlist_url = issue_data.get('playlist', '')
    if playlist_url:
        Script.log(
            f'[NguonC] Đã lấy được playlist '
            f'({issue_data.get("playlistFormat")}): {playlist_url}'
        )
        return playlist_url, ios_headers

    Script.log(f'[NguonC] Không có playlist trong response: {issue_data}')
    return '', ''


@Resolver.register
def play_nguonc(plugin, url, title, movie_slug='', episode_name='',
                resume_pos=0, server_name=''):
    save_watch_history(title, url)
    stream_url, headers = _resolve_embed(url)
    if not stream_url:
        plugin.notify('NguonC', 'Không lấy được link phát cho tập này')
        return False

    Script.log(f'[NguonC] Phát: {stream_url}')

    item = Listitem()
    item.label = title
    item.path = stream_url
    item.listitem.setMimeType('application/vnd.apple.mpegurl')
    item.listitem.setContentLookup(False)
    item.property['inputstream'] = 'inputstream.adaptive'
    item.property['inputstream.adaptive.manifest_type'] = 'hls'
    item.property['inputstream.adaptive.stream_headers'] = headers
    item.property['inputstream.adaptive.manifest_headers'] = headers

    if movie_slug and episode_name:
        _start_resume_tracker(
            movie_slug, episode_name, int(resume_pos or 0), server_name
        )

    return item


def _start_resume_tracker(movie_slug, episode_name, start_pos=0,
                          server_name=''):
    import threading
    import time

    def tracker():
        monitor = Monitor()
        player = Player()

        time.sleep(5)

        if start_pos > 0:
            try:
                waited = 0
                while not player.isPlayingVideo() and waited < 15:
                    time.sleep(1)
                    waited += 1
                if player.isPlayingVideo():
                    player.seekTime(float(start_pos))
                    time.sleep(2)
            except Exception as e:
                Script.log(f'[NguonC] Lỗi seek: {e}')

        last_save = 0
        no_video_count = 0

        while not monitor.abortRequested():
            if player.isPlayingVideo():
                no_video_count = 0
                try:
                    pos = player.getTime()
                    total = player.getTotalTime()
                    now = time.time()
                    if now - last_save >= 10 and total > 30 and pos > 0:
                        save_resume_position(
                            movie_slug, episode_name, pos, total, server_name
                        )
                        last_save = now
                except Exception as e:
                    Script.log(f'[NguonC] Lỗi tracker: {e}')
            else:
                no_video_count += 1
                if no_video_count >= 5:
                    try:
                        pos = player.getTime()
                        total = player.getTotalTime()
                        if total > 30 and pos > 0:
                            save_resume_position(
                                movie_slug, episode_name, pos, total,
                                server_name
                            )
                    except Exception:
                        pass
                    break

            time.sleep(1)

    threading.Thread(target=tracker, daemon=True).start()


# ============================================================
# LỊCH SỬ TÌM KIẾM
# ============================================================

HISTORY_FILE = 'search_history.json'
MAX_HISTORY = 20


def save_search_history(keyword):
    if not keyword:
        return
    history = read_json_file(HISTORY_FILE, [])
    if keyword in history:
        history.remove(keyword)
    history.insert(0, keyword)
    write_json_file(HISTORY_FILE, history[:MAX_HISTORY])


def lich_su_tim_kiem_menu():
    if not read_json_file(HISTORY_FILE, []):
        return
    item = Listitem()
    item.label = '[B]LỊCH SỬ TÌM KIẾM[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(lich_su_tim_kiem)
    yield item


@Route.register
def lich_su_tim_kiem(plugin):
    history = read_json_file(HISTORY_FILE, [])

    clear_item = Listitem()
    clear_item.label = '[B]XÓA TOÀN BỘ LỊCH SỬ[/B]'
    clear_item.art['thumb'] = TRANSPARENT_ICON
    clear_item.set_callback(xoa_lich_su_tim_kiem)
    yield clear_item

    if not history:
        yield _empty('Chưa có lịch sử tìm kiếm')
        return

    for keyword in history:
        item = Listitem()
        item.label = keyword
        item.art['thumb'] = TRANSPARENT_ICON
        item.set_callback(tim_kiem, keyword)
        yield item


@Route.register
def xoa_lich_su_tim_kiem(plugin):
    write_json_file(HISTORY_FILE, [])
    executebuiltin('Container.Refresh()')
    yield Listitem()


# ============================================================
# LỊCH SỬ XEM PHIM
# ============================================================

WATCH_FILE = 'watch_history.json'
MAX_WATCH = 20


def save_watch_history(title, url):
    if not title or not url:
        return
    history = read_json_file(WATCH_FILE, [])
    history = [h for h in history if h.get('title') != title]
    history.insert(0, {'title': title, 'url': url})
    write_json_file(WATCH_FILE, history[:MAX_WATCH])


def lich_su_xem_phim_menu():
    if not read_json_file(WATCH_FILE, []):
        return
    item = Listitem()
    item.label = '[B]LỊCH SỬ XEM PHIM[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(lich_su_xem_phim)
    yield item


@Route.register
def lich_su_xem_phim(plugin):
    history = read_json_file(WATCH_FILE, [])

    clear_item = Listitem()
    clear_item.label = '[B]XÓA TOÀN BỘ LỊCH SỬ[/B]'
    clear_item.art['thumb'] = TRANSPARENT_ICON
    clear_item.set_callback(xoa_lich_su_xem_phim)
    yield clear_item

    if not history:
        yield _empty('Chưa có lịch sử xem phim')
        return

    for entry in history:
        title = entry.get('title', '')
        url = entry.get('url', '')
        if not title or not url:
            continue
        item = Listitem()
        item.label = title
        item.art['thumb'] = TRANSPARENT_ICON
        item.info['mediatype'] = 'episode'
        item.set_callback(play_nguonc, url, title)
        yield item


@Route.register
def xoa_lich_su_xem_phim(plugin):
    write_json_file(WATCH_FILE, [])
    executebuiltin('Container.Refresh()')
    yield Listitem()
