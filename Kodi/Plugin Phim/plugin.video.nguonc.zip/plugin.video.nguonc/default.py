from datetime import date

from codequick import Route, Listitem, run
from resources.lib import nguonc
from resources.lib.utils import setup_kodi_cache

TRANSPARENT_ICON = (
    'https://upload.wikimedia.org/wikipedia/commons/c/ca/1x1.png'
)

# (nhãn, đường dẫn API)
MENU = [
    ('PHIM MỚI CẬP NHẬT', 'films/phim-moi-cap-nhat'),
    ('PHIM LẺ', 'films/danh-sach/phim-le'),
    ('PHIM BỘ', 'films/danh-sach/phim-bo'),
    ('PHIM ĐANG CHIẾU', 'films/danh-sach/phim-dang-chieu'),
    ('TV SHOWS', 'films/danh-sach/tv-shows'),
]


def _entry(label, callback, *args):
    item = Listitem()
    item.label = f'[B]{label}[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(callback, *args)
    return item


@Route.register
def root(plugin):
    """Menu chính của add-on NguonC."""
    setup_kodi_cache()

    yield _entry('TÌM KIẾM', nguonc.tim_kiem_dialog)

    for label, path in MENU:
        yield _entry(label, nguonc.danh_sach, path, 1)

    yield _entry('THỂ LOẠI', nguonc.the_loai)
    yield _entry('QUỐC GIA', nguonc.quoc_gia)
    yield _entry('NGÔN NGỮ', nguonc.ngon_ngu)
    yield _entry('NĂM PHÁT HÀNH', nguonc.nam_phat_hanh, date.today().year)

    yield from nguonc.lich_su_tim_kiem_menu()
    yield from nguonc.lich_su_xem_phim_menu()


if __name__ == '__main__':
    run()
