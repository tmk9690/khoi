"""Bóc tách quảng cáo (SSAI) khỏi playlist HLS (.m3u8) của KKPhim.

Quảng cáo được chèn vào chính playlist (thường ~phút 3 và ~phút 15) dưới dạng
các khối ngắn nằm giữa #EXT-X-DISCONTINUITY, URL khác thư mục/host với phim.

Cách làm:
  1. Tải playlist (master -> chọn chất lượng cao nhất -> media playlist).
  2. Đánh dấu segment quảng cáo: (a) URL khớp mẫu quảng cáo đã biết,
     (b) khối ngắn có "chữ ký" (host + thư mục + dạng tên file) khác phim chính.
  3. Ghi playlist sạch (URL tuyệt đối), phục vụ qua HTTP cục bộ 127.0.0.1.
Lỗi / không chắc chắn -> trả None, add-on phát link gốc như cũ.
Log chẩn đoán: addon_data/plugin.video.kkphim/adfilter_last.txt
"""
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urljoin, urlsplit

import requests

# Mẫu URL quảng cáo đã biết của nguồn KKPhim/phimapi
AD_URI_RE = re.compile(r'convertv\d*/|/v\d+/.*segment_|segment_\d{4}', re.I)
# Khối khác chữ ký dài hơn mức này (giây) -> giữ (có thể là nội dung thật)
MAX_AD_BLOCK_SECONDS = 150
# Khối quảng cáo phải nhỏ hơn tỷ lệ này so với phim chính
MAX_BLOCK_VS_MAIN = 0.2
# Tổng phần bị cắt vượt tỷ lệ này -> nghi nhận diện sai, giữ nguyên
MAX_REMOVED_RATIO = 0.35

HEADER_TAG_RE = re.compile(
    r'^#(EXTM3U|EXT-X-VERSION|EXT-X-TARGETDURATION|EXT-X-MEDIA-SEQUENCE|'
    r'EXT-X-DISCONTINUITY-SEQUENCE|EXT-X-PLAYLIST-TYPE|EXT-X-ALLOW-CACHE|'
    r'EXT-X-INDEPENDENT-SEGMENTS)')
_URI_ATTR = re.compile(r'URI="([^"]*)"')
_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
       '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')

# Bộ header thử lần lượt khi tải playlist
HEADER_SETS = [
    {'User-Agent': _UA, 'Referer': 'https://player.phimapi.com/',
     'Origin': 'https://player.phimapi.com', 'Accept': '*/*'},
    {'User-Agent': _UA, 'Referer': 'https://kkphim.com/', 'Accept': '*/*'},
    {'User-Agent': _UA, 'Accept': '*/*'},
]

_notes = []


def _log(msg):
    _notes.append(msg)
    try:
        from codequick import Script
        Script.log(f'[KKPhim][AdFilter] {msg}')
    except Exception:
        print(f'[KKPhim][AdFilter] {msg}')


def _dump(raw_head, layout=None):
    """Ghi file chẩn đoán để gửi cho người hỗ trợ khi bộ lọc không hiệu quả."""
    try:
        import os
        from resources.lib.utils import ADDON_DATA
        os.makedirs(ADDON_DATA, exist_ok=True)
        with open(os.path.join(ADDON_DATA, 'adfilter_last.txt'), 'w',
                  encoding='utf-8') as f:
            f.write('\n'.join(_notes) + '\n\n')
            if layout:
                f.write('=== BLOCKS ===\n' + layout + '\n\n')
            f.write('=== PLAYLIST (đầu file) ===\n' + raw_head)
    except Exception:
        pass


def _notify(msg):
    try:
        import xbmcgui
        xbmcgui.Dialog().notification('KK Phim', msg, xbmcgui.NOTIFICATION_INFO, 4000)
    except Exception:
        pass


# ------------------------------------------------------------
# Phân tích playlist
# ------------------------------------------------------------

def _sig(url):
    p = urlsplit(url)
    directory, _, filename = p.path.rpartition('/')
    name = re.sub(r'\d+', '#', re.sub(r'[0-9a-fA-F]{16,}', 'H', filename))
    return (p.netloc.lower(), re.sub(r'\d+', '#', directory), name)


def _abs_tag(line, base):
    def fix(m):
        uri = m.group(1)
        if not uri or re.match(r'^[a-z][a-z0-9+.-]*:', uri, re.I):
            return m.group(0)
        return f'URI="{urljoin(base, uri)}"'
    return _URI_ATTR.sub(fix, line) if line.startswith('#') else line


def parse_media(text, base):
    """-> header(list), entries(list of dict), tail(list)"""
    header, entries, tail, pending = [], [], [], []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith('#'):
            if not entries and HEADER_TAG_RE.match(line):
                header.append(line)
            else:
                pending.append(line)
            continue
        uri = urljoin(base, line)
        dur = 0.0
        for t in pending:
            if t.startswith('#EXTINF'):
                m = re.match(r'#EXTINF:([\d.]+)', t)
                dur = float(m.group(1)) if m else 0.0
        disc = any(t.startswith('#EXT-X-DISCONTINUITY')
                   and not t.startswith('#EXT-X-DISCONTINUITY-SEQUENCE')
                   for t in pending)
        entries.append({'tags': pending, 'uri': uri, 'dur': dur,
                        'disc': disc, 'sig': _sig(uri), 'ad': False})
        pending = []
    tail.extend(pending)
    return header, entries, tail


def _blocks(entries):
    """Khối = chuỗi segment liên tiếp; cắt tại DISCONTINUITY hoặc đổi chữ ký."""
    blocks = []
    for i, e in enumerate(entries):
        if (not blocks or e['disc']
                or entries[blocks[-1][-1]]['sig'] != e['sig']):
            blocks.append([i])
        else:
            blocks[-1].append(i)
    return blocks


def mark_ads(entries):
    total = sum(e['dur'] or 1 for e in entries)
    if not total:
        return

    # (a) mẫu URL quảng cáo đã biết — bỏ qua nếu khớp quá nhiều (khớp nhầm cả phim)
    pat = [e for e in entries if AD_URI_RE.search(urlsplit(e['uri']).path)]
    if sum(e['dur'] or 1 for e in pat) / total <= MAX_REMOVED_RATIO:
        for e in pat:
            e['ad'] = True

    # (b) cấu trúc: khối ngắn có chữ ký khác phim chính
    blocks = _blocks(entries)
    sig_time = {}
    for e in entries:
        if not e['ad']:
            sig_time[e['sig']] = sig_time.get(e['sig'], 0) + (e['dur'] or 1)
    if sig_time and len(blocks) > 1:
        main_sig, main_time = max(sig_time.items(), key=lambda kv: kv[1])
        for b in blocks:
            sl = [entries[i] for i in b]
            if all(e['ad'] for e in sl):
                continue
            dur = sum(e['dur'] or 1 for e in sl)
            foreign = all(e['sig'] != main_sig for e in sl)
            if (foreign and dur <= MAX_AD_BLOCK_SECONDS
                    and dur < main_time * MAX_BLOCK_VS_MAIN):
                for e in sl:
                    e['ad'] = True

    removed = sum(e['dur'] or 1 for e in entries if e['ad'])
    if removed / total > MAX_REMOVED_RATIO:
        for e in entries:
            e['ad'] = False


def build_clean(header, entries, tail, base):
    out = [_abs_tag(h, base) for h in header]
    if not out or not out[0].startswith('#EXTM3U'):
        out.insert(0, '#EXTM3U')
    after_ad, emitted = False, 0
    for e in entries:
        if e['ad']:
            after_ad = True
            continue
        tags = e['tags']
        if after_ad:
            tags = [t for t in tags
                    if t.startswith('#EXT-X-DISCONTINUITY-SEQUENCE')
                    or not (t.startswith('#EXT-X-DISCONTINUITY')
                            or t.startswith('#EXT-X-KEY:METHOD=NONE'))]
            if emitted > 0:  # giữ đúng 1 DISCONTINUITY tại chỗ nối
                tags = ['#EXT-X-DISCONTINUITY'] + tags
            after_ad = False
        out.extend(_abs_tag(t, base) for t in tags)
        out.append(e['uri'])
        emitted += 1
    out.extend(_abs_tag(t, base) for t in tail)
    if not any(l.startswith('#EXT-X-ENDLIST') for l in out):
        out.append('#EXT-X-ENDLIST')
    return '\n'.join(out) + '\n'


def describe(entries):
    lines, t = [], 0.0
    for b in _blocks(entries):
        sl = [entries[i] for i in b]
        d = sum(e['dur'] for e in sl)
        lines.append(
            f"@{t/60:5.1f}m {d:6.1f}s {len(sl):4d} seg ad={sum(e['ad'] for e in sl):4d} "
            f"first=...{sl[0]['uri'][-90:]}")
        t += d
    return '\n'.join(lines)


# ------------------------------------------------------------
# Tải & lọc
# ------------------------------------------------------------

def _fetch(url):
    last = None
    for h in HEADER_SETS:
        try:
            r = requests.get(url, headers=h, timeout=15)
            if r.status_code == 200 and '#EXTM3U' in r.text:
                return r.text, r.url
            last = f'HTTP {r.status_code}'
        except Exception as e:
            last = str(e)
    raise RuntimeError(f'không tải được playlist ({last})')


def _variants(text, base):
    out, lines = [], text.splitlines()
    for i, l in enumerate(lines):
        if l.startswith('#EXT-X-STREAM-INF'):
            m = re.search(r'BANDWIDTH=(\d+)', l)
            bw = int(m.group(1)) if m else 0
            for nxt in lines[i + 1:]:
                nxt = nxt.strip()
                if nxt and not nxt.startswith('#'):
                    out.append((bw, urljoin(base, nxt)))
                    break
    return out


def clean_m3u8(url, notify=True):
    """-> playlist sạch (str) hoặc None."""
    del _notes[:]
    raw = ''
    try:
        text, final = _fetch(url)
        _log(f'tải playlist OK: {final}')
        if '#EXT-X-STREAM-INF' in text:
            vs = _variants(text, final)
            if not vs:
                _log('master không có variant')
                return None
            vs.sort(reverse=True)
            _log(f'master: {len(vs)} variant, chọn {vs[0][1]}')
            text, final = _fetch(vs[0][1])
        raw = text[:6000]

        if '#EXT-X-ENDLIST' not in text:
            _log('playlist không có ENDLIST (live?) -> không lọc')
            _dump(raw)
            return None

        header, entries, tail = parse_media(text, final)
        mark_ads(entries)
        n_ad = sum(1 for e in entries if e['ad'])
        sec = sum(e['dur'] for e in entries if e['ad'])
        _log(f'{len(entries)} segment, {len(_blocks(entries))} khối, '
             f'bỏ {n_ad} segment ({sec:.0f}s)')
        _dump(raw, describe(entries))
        if not n_ad:
            if notify:
                _notify('Không nhận diện được quảng cáo (xem adfilter_last.txt)')
            return None
        if notify:
            _notify(f'Đã cắt {sec:.0f}s quảng cáo')
        return build_clean(header, entries, tail, final)
    except Exception as e:
        _log(f'Lỗi bóc tách: {e}')
        _dump(raw)
        if notify:
            _notify('Bóc tách QC lỗi, phát link gốc')
        return None


# ------------------------------------------------------------
# Server cục bộ phục vụ playlist sạch
# ------------------------------------------------------------

def _make_handler(body):
    data = body.encode('utf-8')

    class Handler(BaseHTTPRequestHandler):
        def _send(self, with_body):
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-cache')
            self.end_headers()
            if with_body:
                self.wfile.write(data)

        def do_GET(self):
            self._send(True)

        def do_HEAD(self):
            self._send(False)

        def log_message(self, *args):
            pass

    return Handler


def serve_playlist(body):
    server = ThreadingHTTPServer(('127.0.0.1', 0), _make_handler(body))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return f'http://127.0.0.1:{server.server_address[1]}/index.m3u8', server


def stop_when_playback_ends(server, max_hours=8):
    from xbmc import Monitor, Player

    def run():
        monitor, player = Monitor(), Player()
        waited = 0
        while waited < 90 and not player.isPlaying() and not monitor.abortRequested():
            time.sleep(1)
            waited += 1
        idle, elapsed = 0, 0
        while (not monitor.abortRequested() and idle < 15
               and elapsed < max_hours * 3600):
            idle = 0 if player.isPlaying() else idle + 1
            time.sleep(1)
            elapsed += 1
        try:
            server.shutdown()
            server.server_close()
        except Exception:
            pass

    threading.Thread(target=run).start()
