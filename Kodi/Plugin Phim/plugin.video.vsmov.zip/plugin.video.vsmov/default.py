from codequick import Route, Listitem, run
from resources.lib import vsmov

TRANSPARENT_ICON = (
    'https://upload.wikimedia.org/wikipedia/commons/c/ca/1x1.png'
)


@Route.register
def root(plugin):
    # TÌM KIẾM
    item = Listitem()
    item.label = '[B]TÌM KIẾM[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(vsmov.tim_kiem_dialog)
    yield item

    # PHIM MỚI
    item = Listitem()
    item.label = '[B]PHIM MỚI CẬP NHẬT[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(vsmov.danh_sach, 'phim-moi-cap-nhat', 1)
    yield item

    # PHIM BỘ
    item = Listitem()
    item.label = '[B]PHIM BỘ[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(vsmov.danh_sach, 'phim-bo', 1)
    yield item

    # PHIM LẺ
    item = Listitem()
    item.label = '[B]PHIM LẺ[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(vsmov.danh_sach, 'phim-le', 1)
    yield item

    # THỂ LOẠI
    item = Listitem()
    item.label = '[B]THỂ LOẠI[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(vsmov.the_loai)
    yield item

    # QUỐC GIA
    item = Listitem()
    item.label = '[B]QUỐC GIA[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(vsmov.quoc_gia)
    yield item

    # LỊCH SỬ TÌM KIẾM (chỉ hiện khi có dữ liệu)
    history = vsmov.get_search_history()
    if history:
        item = Listitem()
        item.label = '[B]🕘 LỊCH SỬ TÌM KIẾM[/B]'
        item.art['thumb'] = TRANSPARENT_ICON
        item.set_callback(vsmov.lich_su_tim_kiem)
        yield item


if __name__ == '__main__':
    run()