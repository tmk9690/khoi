import os
import json
import requests
from codequick import Script
from xbmcvfs import translatePath


USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/120.0.0.0 Safari/537.36'
)
BASE_API = 'https://vsmov.com/api'
BASE_WEB = 'https://vsmov.com'
ADDON_DATA = os.path.join(
    translatePath('special://userdata/addon_data'),
    'plugin.video.vsmov'
)


# ============================================================
# HTTP
# ============================================================

def get_json(url, params=None, timeout=30, referer=None, origin=None):
    """Gọi API và trả về JSON."""
    headers = {
        'User-Agent': USER_AGENT,
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'vi-VN,vi;q=0.9,en;q=0.8',
    }
    if referer:
        headers['Referer'] = referer
    if origin:
        headers['Origin'] = origin
    try:
        r = requests.get(url, headers=headers, params=params, timeout=timeout)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        Script.log(f'[VSMOV] Lỗi gọi API {url}: {e}')
        return None


def get_html(url, referer=None, origin=None, timeout=30):
    """Fetch HTML với header đầy đủ."""
    headers = {
        'User-Agent': USER_AGENT,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'vi-VN,vi;q=0.9,en;q=0.8',
    }
    if referer:
        headers['Referer'] = referer
    if origin:
        headers['Origin'] = origin
    try:
        r = requests.get(url, headers=headers, timeout=timeout)
        r.encoding = 'utf-8'
        return r.text
    except Exception as e:
        Script.log(f'[VSMOV] Lỗi fetch HTML {url}: {e}')
        return None


# ============================================================
# HELPERS
# ============================================================

def fix_image(url, size='poster'):
    """
    Tối ưu ảnh cho Kodi — resize + WebP + CDN cache qua wsrv.nl.
    - size='thumb':  150x225
    - size='poster': 300x450 (mặc định, danh sách phim)
    - size='detail': 500x750 (chi tiết phim)
    """
    DEFAULT = 'https://raw.githubusercontent.com/kenvnm/kvn/main/kkphim.png'

    if not isinstance(url, str) or not url.startswith('http'):
        return DEFAULT

    dimensions = {
        'thumb':  (150, 225),
        'poster': (300, 450),
        'detail': (500, 750),
    }
    w, h = dimensions.get(size, (300, 450))

    return f'https://wsrv.nl/?url={url}&w={w}&h={h}&output=webp&q=80&il'


def stream(url, referer='', origin=''):
    """Thêm header vào URL stream cho inputstream."""
    if not url:
        return url
    h = f'User-Agent={USER_AGENT}'
    if referer:
        h += f'&Referer={referer}'
    if origin:
        h += f'&Origin={origin}'
    return f'{url}|{h}'